describe('Test1', () => {
    it('test1', () => {
      cy.visit('http://localhost:3000/')
    })
  })