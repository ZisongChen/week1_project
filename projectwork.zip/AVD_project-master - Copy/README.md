# AVD_project
Please remember to see the Installation guidelines.pdf when configuring your environment. !!!!!!  
In the root directory  
Installation guidelines.pdf  
Project_Report_point.pdf  
User manual.pdf  
are the documentations for the project requirements  
auto_test.mp4 is the demo video of the automation test  
