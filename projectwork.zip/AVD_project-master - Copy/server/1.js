var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
require('dotenv').config();

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
const cors = require('cors');
var app = express();
app.use(cors())
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/testdb');
var sd = require('silly-datetime');

// Introduction of encryption module
const bcrypt = require('bcryptjs')
//Setting the encryption complexity
const salt = bcrypt.genSaltSync(10)


let session = require('express-session')
var cookieSession = require('cookie-session')

var nowuserid = null;
var nowusername =null;

app.use(session({
    name :'connect.sid',
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true,
    cookie:{
        maxAge:1000*60*2,
        httpOnly:true,
    }
  }));

// Import Schema under models file
const Euser =require("./models/Users");
const Book =require("./models/Book");
const storePost =require("./models/Post");
const Comment =require("./models/Comment");
const Post =require("./models/Post");

var Expressjwt=require("express-jwt");
require('dotenv').config()

// Set JWT authentication
app.use(
  Expressjwt
    .expressjwt({
      secret: process.env.SECRET,
      algorithms: ["HS256"],
    })
    .unless({ path: [      
      // The following paths can be used without token
    '/api/book/',
    /\/api\/store/,
    /\/api\/get/,
    /\/api\/delete/,
      /\/api\/user/] })
);

var jwt = require('jsonwebtoken');
var token = jwt.sign({ foo: 'bar' }, 'vawfa');


// The path used by the user to register, the username and password will be sent to this path
app.post("/api/user/register/", (req, res, next) => {
  let dist =0;
  let usern=req.body.email;
  let userp=req.body.password;
  // check the length of the user's registration password, if it does not meet the requirements directly return status400, registration failure
  if (userp.length < 8 ||!/[a-z]/.test(userp) ||!/[A-Z]/.test(userp) ||!/[0-9]/.test(userp) ||!/[~`!@#\$%\^&\*\(\)-_\+=\{\}\[\]|\\;:"<>,\.\/\?]/.test(userp)){
      return res.status(400).json('Password is not strong enough')}
  // Look in Euser's database to see if the registered account name already exists in the database
  Euser.findOne({email:usern}, (err,email) => {
      if (err) return next(err);
      // If the user name does not exist in Euser's database, create a new user to the database and set the token and return it to the front-end
      if(!email){
        let hash = bcrypt.hashSync(userp,salt)
          new Euser({
              email:usern,
              password:hash
          }).save((err) => {
              if (err) return next(err);
          });
          // Set token
          const pplayload = {
            email: usern,
          }
          jwt.sign(
            pplayload,
            process.env.SECRET,
            {
              expiresIn: '1day'
            },
            (err, token) => {
              if (err) throw err;
              return res.send({success: true, token});
            });
      }else{
        // If the username already exists in Euser's database, return a faile
        console.log('FAIL')
        return res.status(400).json('Email already in use');
      }
  })
});

// The path used by the user when logging in, to which the username and password will be sent.
app.post("/api/user/login", (req, res) => {

  let usern=req.body.email;
  let userp=req.body.password;
  // The data received from the front-end is put into the Euser database for searching
  Euser.findOne({email:usern}, (err,userrr) => {
      if (err) return next(err);
      if(!userrr){
        // If the user does not exist, return the user not found
        return res.status(401).json({
          success: false,
          retext: "Invalid user",
        });
      }else{
        // If the user exists, the password is compared, and if it is the same, the token is set and returned
          let userid = userrr._id
          let sotrepassword=userrr.password
          let isOk = bcrypt.compareSync(userp,sotrepassword)
          console.log(123,userid);
          if(isOk){
            nowuserid = userid
              const pplayload = {
                  email: usern,
                }
                jwt.sign(
                  pplayload,
                  process.env.SECRET,
                  {
                    expiresIn: '1day'
                  },
                  (err, token) => {
                    if (err) throw err;
                    console.log(userid)
                    return res.send({success: true, token, id:userrr._id});
                  });
              
          }else{
            // If the user exists, the passwords are compared, and if they are not the same, a password error is returned
              return res.status(401).json({
                success: false,
                retext: "Invalid password",
              });
          } 
      }
  })
});

